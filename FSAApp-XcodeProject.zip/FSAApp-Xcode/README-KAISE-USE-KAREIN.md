# FSA Credit Estimator — Xcode Project (Missing File Fix)

## Yeh kya hai? (What is this?)

Aap ke **FSAApp-iOS.zip** mein sirf Swift source files thin (`Calculator`, `Facilities`, `Inmate Search`, `Saved Results` wali `.swift` files), lekin **Xcode project file** (`project.pbxproj`) mojood nahi thi.

Isi liye Codex keh raha tha ke:
> "ZIP mein Xcode project aur install karne wali .ipa file nahi hai, ise seedha iPhone par install nahi kar sakte."

**Yeh zip wohi missing cheez hai** — `FSAApp.xcodeproj` (project.pbxproj + workspace + app icon). Yeh file aap ke saare `.swift` files ko ek buildable iPhone app bana deti hai.

**Ismein khaas baat:** Yeh project "synchronized folder" technology (Xcode 16+) use karta hai — matlab aap FSAApp folder mein **koi bhi naam** ki `.swift` files daalo, sab khud-ba-khud build mein shamil ho jayengi. File list manually add karne ki zaroorat nahi.

---

## Step 1: Files ko jodhein (2 minute)

1. Yeh zip (`FSAApp-XcodeProject.zip`) extract karo. Ek folder milega jis ke andar:
   ```
   FSAApp.xcodeproj        <- Xcode project file (yehi missing thi)
   FSAApp/                 <- Yahan aap ki Swift files aani hain
      Assets.xcassets/     <- App icon (pehle se mojood, isi tarah rehne do)
   ```
2. Aap ka **purana FSAApp-iOS.zip** extract karo.
3. Us zip ke andar ki **saari `.swift` files (aur unke sub-folders bhi)** copy kar ke `FSAApp` folder ke andar daal do.
4. Double-click `FSAApp.xcodeproj` → Xcode khul jayega aur FSAApp folder ki saari files left sidebar mein nazar aayengi.

**Zaroori:** Agar aap ke FSAApp-iOS.zip mein `Assets.xcassets` naam ka folder bhi ho, to usko copy **mat** karo (icon ka dobara hone se error aata hai). Sirf `.swift` files copy karo.

---

## Step 2: iPhone par install (Mac par)

> Note: Xcode 16 ya naya version chahiye (Mac App Store se free hai). Sirf macOS 14+ wale Mac par chalega.

1. Xcode kholein → left sidebar mein `FSAApp` project par click → target `FSAApp` select karein.
2. **Signing & Capabilities** tab:
   - `Automatically manage signing` par tick rakhein
   - **Team** mein apna Apple ID select karein
   - (Agar Apple ID add nahi hai: Xcode → Settings → Accounts → `+` → apna Apple ID daalein — free hai, developer account ki zaroorat nahi)
   - Bundle ID already `com.firststepact.creditestimator` hai. Agar signing error aaye to isko thora unique bana dein (e.g. `com.apki123.fsaapp`).
3. iPhone ko cable se connect karein → iPhone par "Trust This Computer" par tap karein.
4. Xcode ke top toolbar mein device list se apna iPhone select karein → **Run (▶)** dabayen.
5. Pehli baar install ke baad iPhone par:
   - Settings → General → **VPN & Device Management** → apna Apple Developer profile → **Trust**
6. App icon (blue, scales of justice) home screen par aa jayegi.

**Free Apple ID ki limit:** App 7 din baad expire hoti hai, phir Xcode se dobara Run karna hoga. $99/year ke paid developer account se hamesha chalti hai + TestFlight se doosron ko bhej sakte hain.

---

## Step 3: Agar Mac nahi hai? (Sirf Windows)

`.ipa` banane ke liye kahin na kahin macOS chahiye (Xcode sirf Mac par chalta hai). Options:

**Option A — Codemagic.io (recommended, Mac ke baghair):**
1. GitHub par free account bana kar yeh poora folder ek repo mein push karein (FSAApp folder ki saari .swift files samet).
2. codemagic.io par sign-up karein (free tier mein macOS minutes milte hain).
3. App select karein → workflow: iOS App → `Debug` build type chunein → build karein → `.ipa` mil jayegi.
4. Signing ke liye Apple ID ki zaroorat hogi (Codemagic guidance follow karein).

**Option B — Kisi dost / office / cyber cafe ke Mac par:**
Yeh zip + apna FSAApp-iOS.zip USB ya email se le ja kar Step 2 follow karein — sirf 10 minute ka kaam hai.

**Install alternatives (jab .ipa mil jaye):**
- Windows par **Sideloadly** ya **AltStore** (free Apple ID se, 7 din ki limit)
- Paid developer account ho to iTunes/Apple Configurator se direct install

---

## Common errors aur hal

| Error | Matlab | Hal |
|---|---|---|
| `no @main` / empty project | FSAApp folder mein .swift files copy karna bhool gaye | Step 1 dobara karein |
| `Multiple assets named AppIcon` | Aap ke zip ka Assets.xcassets bhi copy ho gaya | Duplicate Assets.xcassets delete karein |
| Signing/team error | Apple ID select nahi hui | Signing & Capabilities → Team select |
| `iOS 18.x is not available` type errors | Aap ke Swift code mein naye iOS APIs use hue hain | Target → Build Settings → `iOS Deployment Target` 18.0 kar dein |
| `NavigationStack is only available in iOS 16+` | Deployment target kam hai | Deployment target 17.0+ rakhein (already set hai) |
| App iPhone par khulti nahi / untrusted | Developer trust nahi hua | Settings → General → VPN & Device Management → Trust |

---

## Project settings (jo already set hain)

- **App name (home screen par):** FSA Credit Estimator
- **Bundle ID:** com.firststepact.creditestimator
- **Deployment target:** iOS 17.0
- **Orientation:** Portrait only
- **Icon + Accent color:** Blue (#2563EB) — client ke mockup ke mutabiq
- **Version:** 1.0

Settings badalni hon to: Xcode → FSAApp target → General tab mein sab kuch GUI se mil jata hai.

---

## Ek line mein summary

**Missing file** = `FSAApp.xcodeproj` ka `project.pbxproj` (Xcode project definition). Yeh zip woh deta hai + app icon. Bas apni `.swift` files `FSAApp` folder mein daalo, Xcode mein kholo, Team select karo, Run dabao — iPhone par install ho jayegi. `.ipa` file banana macOS/Xcode build ke baghair mumkin nahi (Codemagic ya kisi Mac se hoga).
